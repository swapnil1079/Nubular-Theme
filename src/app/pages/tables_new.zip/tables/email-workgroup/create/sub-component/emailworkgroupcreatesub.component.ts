import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, FormArray, Validators, FormBuilder, NgForm } from '@angular/forms';
import { UserService } from '../../../../../core/@services/user.service';

@Component({
    selector: 'address',
    templateUrl: './form-sub-component.html'
})
export class EmailWorkGroupCreateSubComponent implements OnInit {
    @Input('group') 
    public adressForm: FormGroup;
    // active: boolean;
    // confidential: boolean;
    Optionmodel: any;
    Optionlocale: any;
    isreadonly:boolean;
    model: any;
    currentPage =1 ;
    @Input() itemIndex: number;
    @Output('valuechecker') eventval = new EventEmitter();
    useExisting: boolean;
    ShowList: boolean = false;
    ShowOption: boolean = true;
    constructor(private UserService: UserService) { }
    async ngOnInit() {
        console.log(this.itemIndex);
        let res = await this.UserService.getAllEmailTemplate(this.currentPage);
        if (res) {
            this.Optionmodel = res;
        }
        
        

    }
    clickevent(event) {

        
        if (event == true) {
            this.eventval.emit({ event: true });
            this.ShowList = false;
        }
        else {
            this.eventval.emit({ event: false });
            this.ShowList = true;
        }
    }

    async SelectedOption($event) {
        console.log($event.target.value);
        if ($event.target.value == "Create New") {

            this.ShowList = true;
            this.model = {};
            // this.model.active = true;
            // this.model.confidential = true;
            this.isreadonly = false;
            if(this.itemIndex==0)
        {
            this.model.numberOfDaysToWait = 0;
            this.model.sequentialOrder = 1;
            console.log(this.model);
            
        }
        else{
            this.model.sequentialOrder = this.itemIndex+1;
        }
        }
        else {
            //console.log($event.target.value);
            var name = $event.target.value.split(": ")[1]
            console.log(name)
            this.ShowList = true;
            this.isreadonly = true;
             this.UserService.getTemplateByName(name).subscribe(result => {
     //var singlelist =  []; 
     // singlelist.push(result);
             this.model = result;
     if(this.itemIndex==0)
        {
            
            this.model.numberOfDaysToWait = 0;
            this.model.sequentialOrder = 1;
            //console.log(this.model);
            
        }
        else
        {
            this.model.sequentialOrder = this.itemIndex+1;
        }
             
    });
        }
        this.UserService.lookupapi().subscribe(result=>{
      this.Optionlocale = result;
    });

    }
        }

