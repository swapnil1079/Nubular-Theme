export class DataModel {
    
    name: string;
    job: string;
    
  }