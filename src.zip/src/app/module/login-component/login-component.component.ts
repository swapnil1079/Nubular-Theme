import { Component, OnInit } from '@angular/core';
import { LoginServiceService } from '../../core/@services/login-service.service';
import { FormGroup, FormControl, FormArray, Validators, FormBuilder, NgForm } from '@angular/forms';
import { CustomValidators } from '../../shared/validators/custom-validators';
import { ValidationService } from "../../shared/validators/validation.service";
import{UserStorageService} from "../../core/@services/UserStorage.service";
import {Router} from '@angular/router';



@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit {

  constructor(private Loginservice: LoginServiceService,private fb: FormBuilder,ValidationService:ValidationService, private store:UserStorageService,private router:Router) { }
    myForm: FormGroup;
  ngOnInit() {
    //this.store.SetUserResponse(1160);
    this.myForm = this.fb.group({
      'email': ['', [Validators.required,ValidationService.emailValidator]],
      'password': ['', Validators.required]
    });
  }
  login(myForm:any) {
    // console.log(this.store.GetUserResponse());
    // console.log('Registration successful.');
    this.Loginservice.getLogin(myForm.value).subscribe(result=>{
      console.log(result);
     this.store.SetToken(result.token+new Date().getTime());
      this.store.SetUserDetails(myForm.value.email);
      this.router.navigate(['/pages/dashboard']);
    })
    // console.log(myForm.value);
  }

}
