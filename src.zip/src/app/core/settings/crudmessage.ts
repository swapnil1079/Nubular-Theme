export class CrudMessage {
  
  public static success_insert = 'Inserted Successfully';
  public static success_update = 'Updated Successfully';
  public static success_delete = 'Deleted Successfully';
  
}