export interface EmailTypeModel {
  name: string;
  value: string;
}