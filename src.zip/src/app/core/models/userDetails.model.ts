export class UserDetails {
    email : string;
}