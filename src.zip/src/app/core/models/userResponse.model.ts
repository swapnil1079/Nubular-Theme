import {UserDetails} from './UserDetails.model';

export class UserResponse {
    userDetails : UserDetails;
    token : string;

}