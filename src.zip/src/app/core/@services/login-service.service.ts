import { Injectable } from '@angular/core';
import { Observable } from "rxjs/Rx"
import { Response, Headers, RequestOptions,Http } from '@angular/http';
import { HttpHeaders,HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { AppSettings } from '../settings/appsetting';


@Injectable({
  providedIn: 'root'
})
export class LoginServiceService extends AppSettings  {

  constructor( private http: HttpClient,
    private _router: Router) { super(); }

  public getLogin(userDetails): Observable<any> {
   return this.http.post(AppSettings.loginApiUrl,userDetails).map((response: Response) => {
     console.log(response);
      return response;

    });
  }
}
