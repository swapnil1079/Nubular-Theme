import { Component } from '@angular/core';

@Component({
  selector: 'ngx-spinner-sizes',
  templateUrl: 'spinner-sizes.component.html',
})

export class SpinnerSizesComponent {
}
