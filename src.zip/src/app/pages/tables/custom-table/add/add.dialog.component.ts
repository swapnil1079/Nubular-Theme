import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Component, Inject, OnInit, AfterViewChecked, AfterContentChecked } from '@angular/core';
import { ValidationService } from "../../../../shared/validators/validation.service";
import { DataModel } from '../model/data.model'
import { FormGroup, FormControl, FormArray, Validators, FormBuilder, NgForm } from '@angular/forms';
import { UserService } from '../../../../core/@services/user.service'
import { LoaderService } from '../../../../core/@services/loader.service'
import '../../../editors/ckeditor/ckeditor.loader';
import 'ckeditor';

@Component({
  selector: 'app-add.dialog',
  templateUrl: './add.dialog.html',
  styleUrls: ['./add.dialog.scss']
})

export class AddDialogComponent implements OnInit {
  active: true;
  confidential: false;
  Optionmodel : any;
  constructor(public dialogRef: MatDialogRef<AddDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DataModel, private fb: FormBuilder, public ValidationService: ValidationService, private UserService: UserService, private loaderservice: LoaderService
  ) { }
  myForm: FormGroup;
  ngOnInit() {
    this.loaderservice.show();
    this.myForm = this.fb.group({
      'name': ['', [Validators.required]],
      'defaultSubject': ['', [Validators.required]],
      'displayFromName': ['', [Validators.required]],
      'locale': ['', [Validators.required]],
      'body': ['', [Validators.required]],
      'active': [],
      'confidential': []

    });
    setTimeout(() => {
      this.loaderservice.hide()
    }, 3000)
    this.UserService.lookupapi().subscribe(result=>{
      this.Optionmodel = result;
    });
  }


  submit(myForm: any) {
    //console.log(myForm.value);
    this.UserService.EmailTemplateAdd(myForm.value).subscribe(result => {
      this.dialogRef.close(result);
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}

